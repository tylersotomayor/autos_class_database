from random_autos import generate_random_autos
autos_data = generate_random_autos(100)

"""autos_data = [
    {"vin": "1G1YY26W185100001", "make": "Chevrolet", "model": "Corvette", "year": 2008, "fuel_economy": 16.0, "price": 21999.99},
    {"vin": "3D7KS29C46G151092", "make": "Dodge", "model": "Ram 2500", "year": 2006, "fuel_economy": 13.5, "price": 14999.99},
    {"vin": "1C4HJWDG8DL501317", "make": "Jeep", "model": "Wrangler", "year": 2013, "fuel_economy": 17.2, "price": 22999.99},
    {"vin": "2GTEK13M371176321", "make": "GMC", "model": "Sierra 1500", "year": 2007, "fuel_economy": 14.8, "price": 16999.99},
    {"vin": "WBAVB13586KR61654", "make": "BMW", "model": "3 Series", "year": 2006, "fuel_economy": 21.4, "price": 10999.99},
    {"vin": "1GNKVGED1CJ246621", "make": "Chevrolet", "model": "Traverse", "year": 2012, "fuel_economy": 18.0, "price": 13999.99},
    {"vin": "1GCEK19T9YE369223", "make": "Chevrolet", "model": "Silverado 1500", "year": 2000, "fuel_economy": 13.0, "price": 7999.99},
    {"vin": "WDDGF8BB9BR185546", "make": "Mercedes-Benz", "model": "C-Class", "year": 2011, "fuel_economy": 20.0, "price": 12999.99},
    {"vin": "WAUCFAFH1AN041753", "make": "Audi", "model": "A6", "year": 2010, "fuel_economy": 21.0, "price": 12999.99},
    {"vin": "1C3CCBBG5DN584607", "make": "Chrysler", "model": "200", "year": 2013, "fuel_economy": 24.0, "price": 10499.99},
    {"vin": "5NPDH4AE5EH452480", "make": "Hyundai", "model": "Elantra", "year": 2014, "fuel_economy": 31.0, "price": 10999.99},
    {"vin": "1C6RR7FTXES256029", "make": "Ram", "model": "1500", "year": 2014, "fuel_economy": 19.0, "price": 23999.99},
    {"vin": "WAUEFAFL8EN046790", "make": "Audi", "model": "A4", "year": 2014, "fuel_economy": 24.0, "price": 13999.99}]"""